export function Layout(content) {
    return `
        <nav class="navbar glass">
            <div class="container flex justify-between items-center">
                <a href="#" class="text-gradient" style="font-size: 1.5rem; font-weight: 700; text-decoration: none;">Gelişim</a>
                <div class="flex gap-8">
                    <a href="#" class="nav-link">Ana Sayfa</a>
                    <a href="#dashboard" class="nav-link">Panelim</a>
                </div>
            </div>
        </nav>

        <main style="padding-top: 80px; min-height: calc(100vh - 200px);">
            ${content}
        </main>

        <footer class="glass" style="margin-top: 4rem; padding: 2rem 0; border-top: 1px solid var(--glass-border);">
            <div class="container flex justify-between items-center">
                <p style="color: var(--text-muted);">© 2025 Gelişim App. Tüm hakları saklıdır.</p>
                <div class="flex gap-4">
                    <a href="#" style="color: var(--text-muted);"><i data-lucide="instagram"></i></a>
                    <a href="#" style="color: var(--text-muted);"><i data-lucide="twitter"></i></a>
                </div>
            </div>
        </footer>
    `;
}
