export const behaviors = [
    {
        id: 'meditation',
        title: 'Meditasyon',
        shortDescription: 'Zihinsel berraklık ve iç huzur için günlük pratik.',
        fullDescription: `
            <p>Meditasyon, zihni odaklama ve yönlendirme pratiğidir. Binlerce yıldır uygulanan bu yöntem, günümüzde stres yönetimi ve zihinsel sağlık için en etkili araçlardan biri olarak kabul edilmektedir.</p>
            <h3>Neden Meditasyon Yapmalısınız?</h3>
            <ul>
                <li><strong>Stresi Azaltır:</strong> Kortizol seviyelerini düşürerek rahatlama sağlar.</li>
                <li><strong>Odaklanmayı Artırır:</strong> Dikkat süresini uzatır ve zihinsel dağınıklığı önler.</li>
                <li><strong>Duygusal Denge:</strong> Kendini tanıma ve duygusal zekayı geliştirir.</li>
            </ul>
            <h3>Nasıl Başlanır?</h3>
            <p>Günde sadece 5 dakika ile başlayın. Rahat bir pozisyonda oturun, gözlerinizi kapatın ve nefesinize odaklanın. Düşünceler geldiğinde onları yargılamadan izleyin ve tekrar nefesinize dönün.</p>
        `,
        category: 'Zihinsel',
        image: 'https://images.unsplash.com/photo-1593811167562-9cef47bfc4d7?q=80&w=2072&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/inpok4MKVLM', // Placeholder
        rating: 4.9,
        reviews: [
            { user: 'Ayşe K.', comment: 'Hayatımı değiştirdi, artık çok daha sakinim.', rating: 5 },
            { user: 'Mehmet Y.', comment: 'Başta zordu ama şimdi vazgeçilmezim.', rating: 4 }
        ]
    },
    {
        id: 'pomodoro',
        title: 'Pomodoro Tekniği',
        shortDescription: 'Zaman yönetimi ve üretkenlik için 25 dakikalık odaklanma.',
        fullDescription: `
            <p>Pomodoro Tekniği, 1980'lerin sonunda Francesco Cirillo tarafından geliştirilen bir zaman yönetimi yöntemidir. Teknik, işi molalarla ayrılmış kısa zaman aralıklarına (genellikle 25 dakika) böler.</p>
            <h3>Tekniğin Faydaları</h3>
            <ul>
                <li>Zihinsel yorgunluğu azaltır.</li>
                <li>Dikkat dağıtıcı unsurları yönetmeyi kolaylaştırır.</li>
                <li>İşleri bitirme motivasyonunu artırır.</li>
            </ul>
            <h3>Uygulama Adımları</h3>
            <ol>
                <li>Yapılacak işi seçin.</li>
                <li>Zamanlayıcıyı 25 dakikaya ayarlayın.</li>
                <li>Zamanlayıcı çalana kadar çalışın.</li>
                <li>5 dakikalık kısa bir mola verin.</li>
                <li>Her 4 "Pomodoro"dan sonra 15-30 dakikalık uzun bir mola verin.</li>
            </ol>
        `,
        category: 'Üretkenlik',
        image: 'https://images.unsplash.com/photo-1456324504439-367cee3b3c32?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/mNBmG24djoY',
        rating: 4.7,
        reviews: [
            { user: 'Canan T.', comment: 'Ders çalışırken odaklanmamı sağlayan tek yöntem.', rating: 5 }
        ]
    },
    {
        id: 'hydration',
        title: 'Su İçme Takibi',
        shortDescription: 'Enerji ve sağlık için günlük su tüketimi.',
        fullDescription: `
            <p>Vücudumuzun yaklaşık %60'ı sudur. Yeterli su içmek, sadece hayatta kalmak için değil, optimal sağlık ve performans için de kritiktir.</p>
            <h3>Susuzluğun Etkileri</h3>
            <p>Hafif bir susuzluk bile enerji düşüklüğüne, baş ağrısına ve konsantrasyon bozukluğuna yol açabilir.</p>
            <h3>Hedefiniz Ne Olmalı?</h3>
            <p>Genel bir kural olarak günde en az 8 bardak (yaklaşık 2 litre) su içilmesi önerilir, ancak bu miktar aktivite seviyenize göre artabilir.</p>
        `,
        category: 'Sağlık',
        image: 'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?q=80&w=1888&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/9iMGFqMmUFs',
        rating: 4.8,
        reviews: []
    },
    {
        id: 'steps',
        title: '10.000 Adım',
        shortDescription: 'Aktif bir yaşam için günlük hareket hedefi.',
        fullDescription: `
            <p>Günlük adım hedefi koymak, hareketsiz yaşam tarzıyla mücadele etmenin en basit ve etkili yoludur. Yürüyüş yapmak kalp sağlığını korur, kilo kontrolüne yardımcı olur ve ruh halini iyileştirir.</p>
        `,
        category: 'Fiziksel',
        image: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/_kGESn8ArrU',
        rating: 4.6,
        reviews: []
    },
    {
        id: 'deadline',
        title: 'Deadline Yönetimi',
        shortDescription: 'Son teslim tarihlerine sadık kalarak stresi yenin.',
        fullDescription: `
            <p>Deadline (son teslim tarihi) yönetimi, profesyonel başarının anahtarıdır. İşleri son dakikaya bırakmamak, kalitesiz iş çıkmasını ve yüksek stresi önler.</p>
        `,
        category: 'Kariyer',
        image: 'https://images.unsplash.com/photo-1506784983877-45594efa4cbe?q=80&w=2068&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/QJ2Fp6h9c2c',
        rating: 4.5,
        reviews: []
    }
];
