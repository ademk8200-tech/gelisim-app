// Data
const behaviors = [
    {
        id: 'meditation',
        title: 'Meditasyon',
        shortDescription: 'Zihinsel berraklık ve iç huzur için günlük pratik.',
        fullDescription: `
            <p>Meditasyon, zihni odaklama ve yönlendirme pratiğidir. Binlerce yıldır uygulanan bu yöntem, günümüzde stres yönetimi ve zihinsel sağlık için en etkili araçlardan biri olarak kabul edilmektedir.</p>
            <h3>Neden Meditasyon Yapmalısınız?</h3>
            <ul>
                <li><strong>Stresi Azaltır:</strong> Kortizol seviyelerini düşürerek rahatlama sağlar.</li>
                <li><strong>Odaklanmayı Artırır:</strong> Dikkat süresini uzatır ve zihinsel dağınıklığı önler.</li>
                <li><strong>Duygusal Denge:</strong> Kendini tanıma ve duygusal zekayı geliştirir.</li>
            </ul>
            <h3>Nasıl Başlanır?</h3>
            <p>Günde sadece 5 dakika ile başlayın. Rahat bir pozisyonda oturun, gözlerinizi kapatın ve nefesinize odaklanın. Düşünceler geldiğinde onları yargılamadan izleyin ve tekrar nefesinize dönün.</p>
        `,
        category: 'Zihinsel',
        image: 'https://images.unsplash.com/photo-1593811167562-9cef47bfc4d7?q=80&w=2072&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/inpok4MKVLM',
        rating: 4.9,
        reviews: [
            { user: 'Ayşe K.', comment: 'Hayatımı değiştirdi, artık çok daha sakinim.', rating: 5 },
            { user: 'Mehmet Y.', comment: 'Başta zordu ama şimdi vazgeçilmezim.', rating: 4 }
        ]
    },
    {
        id: 'pomodoro',
        title: 'Pomodoro Tekniği',
        shortDescription: 'Zaman yönetimi ve üretkenlik için 25 dakikalık odaklanma.',
        fullDescription: `
            <p>Pomodoro Tekniği, 1980'lerin sonunda Francesco Cirillo tarafından geliştirilen bir zaman yönetimi yöntemidir. Teknik, işi molalarla ayrılmış kısa zaman aralıklarına (genellikle 25 dakika) böler.</p>
            <h3>Tekniğin Faydaları</h3>
            <ul>
                <li>Zihinsel yorgunluğu azaltır.</li>
                <li>Dikkat dağıtıcı unsurları yönetmeyi kolaylaştırır.</li>
                <li>İşleri bitirme motivasyonunu artırır.</li>
            </ul>
            <h3>Uygulama Adımları</h3>
            <ol>
                <li>Yapılacak işi seçin.</li>
                <li>Zamanlayıcıyı 25 dakikaya ayarlayın.</li>
                <li>Zamanlayıcı çalana kadar çalışın.</li>
                <li>5 dakikalık kısa bir mola verin.</li>
                <li>Her 4 "Pomodoro"dan sonra 15-30 dakikalık uzun bir mola verin.</li>
            </ol>
        `,
        category: 'Üretkenlik',
        image: 'https://images.unsplash.com/photo-1456324504439-367cee3b3c32?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/mNBmG24djoY',
        rating: 4.7,
        reviews: [
            { user: 'Canan T.', comment: 'Ders çalışırken odaklanmamı sağlayan tek yöntem.', rating: 5 }
        ]
    },
    {
        id: 'hydration',
        title: 'Su İçme Takibi',
        shortDescription: 'Enerji ve sağlık için günlük su tüketimi.',
        fullDescription: `
            <p>Vücudumuzun yaklaşık %60'ı sudur. Yeterli su içmek, sadece hayatta kalmak için değil, optimal sağlık ve performans için de kritiktir.</p>
            <h3>Susuzluğun Etkileri</h3>
            <p>Hafif bir susuzluk bile enerji düşüklüğüne, baş ağrısına ve konsantrasyon bozukluğuna yol açabilir.</p>
            <h3>Hedefiniz Ne Olmalı?</h3>
            <p>Genel bir kural olarak günde en az 8 bardak (yaklaşık 2 litre) su içilmesi önerilir, ancak bu miktar aktivite seviyenize göre artabilir.</p>
        `,
        category: 'Sağlık',
        image: 'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?q=80&w=1888&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/9iMGFqMmUFs',
        rating: 4.8,
        reviews: []
    },
    {
        id: 'steps',
        title: '10.000 Adım',
        shortDescription: 'Aktif bir yaşam için günlük hareket hedefi.',
        fullDescription: `
            <p>Günlük adım hedefi koymak, hareketsiz yaşam tarzıyla mücadele etmenin en basit ve etkili yoludur. Yürüyüş yapmak kalp sağlığını korur, kilo kontrolüne yardımcı olur ve ruh halini iyileştirir.</p>
        `,
        category: 'Fiziksel',
        image: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/_kGESn8ArrU',
        rating: 4.6,
        reviews: []
    },
    {
        id: 'deadline',
        title: 'Deadline Yönetimi',
        shortDescription: 'Son teslim tarihlerine sadık kalarak stresi yenin.',
        fullDescription: `
            <p>Deadline (son teslim tarihi) yönetimi, profesyonel başarının anahtarıdır. İşleri son dakikaya bırakmamak, kalitesiz iş çıkmasını ve yüksek stresi önler.</p>
        `,
        category: 'Kariyer',
        image: 'https://images.unsplash.com/photo-1506784983877-45594efa4cbe?q=80&w=2068&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/QJ2Fp6h9c2c',
        rating: 4.5,
        reviews: []
    },
    {
        id: 'journaling',
        title: 'Günlük Tutma',
        shortDescription: 'Düşünceleri düzenlemek ve farkındalık için yazma pratiği.',
        fullDescription: `
            <p>Günlük tutmak (Journaling), zihninizi boşaltmanın ve duygusal zekanızı geliştirmenin en etkili yollarından biridir. Sadece yaşananları değil, hissettiklerinizi ve hedeflerinizi de yazmak, kendinizi daha iyi tanımanızı sağlar.</p>
            <h3>Faydaları</h3>
            <ul>
                <li>Stresi ve kaygıyı azaltır.</li>
                <li>Hafızayı güçlendirir.</li>
                <li>Yaratıcılığı artırır.</li>
            </ul>
        `,
        category: 'Zihinsel',
        image: 'https://images.unsplash.com/photo-1517842645767-c639042777db?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/V7ogj8Z8G0s',
        rating: 4.8,
        reviews: []
    },
    {
        id: 'reading',
        title: 'Kitap Okuma',
        shortDescription: 'Her gün en az 20 sayfa okuyarak zihni besleme.',
        fullDescription: `
            <p>Okumak, beynin egzersizidir. Düzenli okuma alışkanlığı, kelime dağarcığını geliştirir, empati yeteneğini artırır ve stresi azaltır.</p>
            <h3>Nasıl Alışkanlık Haline Getirilir?</h3>
            <p>Her gün aynı saatte, sessiz bir ortamda 20 dakika ayırarak başlayın. Yanınızda her zaman bir kitap bulundurun.</p>
        `,
        category: 'Zihinsel',
        image: 'https://images.unsplash.com/photo-1491841550275-ad7854e35ca6?q=80&w=1974&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/472MyoY0rQc',
        rating: 4.9,
        reviews: []
    },
    {
        id: 'digital-detox',
        title: 'Dijital Detoks',
        shortDescription: 'Teknolojiden uzaklaşarak ana odaklanma.',
        fullDescription: `
            <p>Sürekli bildirimler ve ekran ışığı, zihinsel yorgunluğun en büyük sebeplerinden biridir. Dijital detoks, belirli sürelerde (örneğin yatmadan 1 saat önce veya pazar günleri) tüm ekranlardan uzak durmayı içerir.</p>
        `,
        category: 'Sağlık',
        image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/RPsLpM5h1jE',
        rating: 4.6,
        reviews: []
    },
    {
        id: 'early-rising',
        title: 'Erken Kalkmak',
        shortDescription: 'Güne erken başlayarak üretkenliği artırma.',
        fullDescription: `
            <p>"Erken kalkan yol alır." Sabahın sessizliği, odaklanmak ve günü planlamak için en verimli zamandır. Biyolojik saatinizi düzenleyerek daha enerjik hissedebilirsiniz.</p>
        `,
        category: 'Üretkenlik',
        image: 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/qM4j7rF9b0E',
        rating: 4.4,
        reviews: []
    },
    {
        id: 'gratitude',
        title: 'Şükran Günlüğü',
        shortDescription: 'Pozitifliğe odaklanmak için minnettar olunanları yazma.',
        fullDescription: `
            <p>Her gün minnettar olduğunuz 3 şeyi yazmak, beyninizi pozitifliğe odaklar. Bu basit pratik, uzun vadede mutluluk seviyesini artırır ve depresif düşünceleri azaltır.</p>
        `,
        category: 'Ruhsal',
        image: 'https://images.unsplash.com/photo-1507643179173-617d6c79a697?q=80&w=2068&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/U5lZBjWDR_c',
        rating: 4.9,
        reviews: []
    },
    {
        id: 'yoga-breathing',
        title: 'Yoga Nefes Egzersizleri',
        shortDescription: 'Stresi azaltmak ve odaklanmayı artırmak için Pranayama.',
        fullDescription: `
            <p>Pranayama olarak bilinen yoga nefes egzersizleri, zihni sakinleştirmenin en hızlı yoludur. Derin ve kontrollü nefes almak, sinir sistemini dengeler.</p>
            <h3>Faydaları</h3>
            <ul>
                <li>Anında rahatlama sağlar.</li>
                <li>Akciğer kapasitesini artırır.</li>
                <li>Zihinsel berraklık kazandırır.</li>
            </ul>
        `,
        category: 'Zihinsel',
        image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?q=80&w=2031&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/inpok4MKVLM',
        rating: 4.8,
        reviews: []
    },
    {
        id: 'networking',
        title: 'Networking',
        shortDescription: 'Kariyer fırsatları için profesyonel ağ oluşturma.',
        fullDescription: `
            <p>Networking, sadece kartvizit alışverişi değil, uzun vadeli ilişkiler kurmaktır. Doğru insanlarla tanışmak, kariyerinizde yeni kapılar açabilir.</p>
        `,
        category: 'Kariyer',
        image: 'https://images.unsplash.com/photo-1515187029135-18ee286d815b?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/QJ2Fp6h9c2c',
        rating: 4.5,
        reviews: []
    },
    {
        id: 'budgeting',
        title: 'Bütçe Planlaması',
        shortDescription: 'Finansal özgürlük için gelir-gider takibi.',
        fullDescription: `
            <p>Paranızı yönetmek, hayatınızı yönetmektir. Basit bir bütçe planı ile gereksiz harcamaları kısıp, hayalleriniz için birikim yapabilirsiniz.</p>
        `,
        category: 'Finans',
        image: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?q=80&w=2026&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/9iMGFqMmUFs',
        rating: 4.7,
        reviews: []
    },
    {
        id: 'minimalism',
        title: 'Minimalizm',
        shortDescription: 'Az eşya, çok huzur felsefesi.',
        fullDescription: `
            <p>Minimalizm, sadece eşyaları azaltmak değil, hayattaki fazlalıklardan kurtulup önemli olana odaklanmaktır. Sadeleşmek zihni rahatlatır.</p>
        `,
        category: 'Yaşam',
        image: 'https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?q=80&w=2067&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/RPsLpM5h1jE',
        rating: 4.6,
        reviews: []
    },
    {
        id: 'public-speaking',
        title: 'Topluluk Önünde Konuşma',
        shortDescription: 'İletişim becerilerini ve özgüveni geliştirme.',
        fullDescription: `
            <p>Topluluk önünde konuşmak, birçok insanın korkusudur ancak kariyer basamaklarını tırmanmak için kritik bir yetenektir. Pratik yaparak bu korkuyu yenebilirsiniz.</p>
        `,
        category: 'Kariyer',
        image: 'https://images.unsplash.com/photo-1475721027767-4d537d375389?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/QJ2Fp6h9c2c',
        rating: 4.4,
        reviews: []
    },
    {
        id: 'intermittent-fasting',
        title: 'Aralıklı Oruç',
        shortDescription: 'Sağlıklı yaşam ve zihinsel netlik için beslenme düzeni.',
        fullDescription: `
            <p>Aralıklı oruç (Intermittent Fasting), belirli saatlerde yemek yiyip geri kalan zamanda oruç tutmayı içerir. Hücresel yenilenmeyi destekler.</p>
        `,
        category: 'Sağlık',
        image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?q=80&w=2053&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/9iMGFqMmUFs',
        rating: 4.5,
        reviews: []
    },
    {
        id: 'fitness',
        title: 'Fitness Antrenmanı',
        shortDescription: 'Güçlü bir vücut ve zihin için düzenli egzersiz.',
        fullDescription: `
            <p>Haftada en az 3 gün yapılan direnç veya kardiyo antrenmanları, endorfin salgılatarak mutluluk verir ve özgüveni artırır.</p>
        `,
        category: 'Fiziksel',
        image: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/_kGESn8ArrU',
        rating: 4.9,
        reviews: []
    },
    {
        id: 'daily-goals',
        title: 'Günlük Hedefler',
        shortDescription: 'Her güne bir amaç belirleyerek başla.',
        fullDescription: `
            <p>Güne başlarken belirleyeceğiniz 3 ana hedef, gün boyu pusulanız olur. Küçük başarılar, büyük motivasyon sağlar.</p>
        `,
        category: 'Üretkenlik',
        image: 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?q=80&w=2072&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/mNBmG24djoY',
        rating: 4.7,
        reviews: []
    },
    {
        id: 'self-care',
        title: 'Kişisel Bakım Rutini',
        shortDescription: 'Kendine zaman ayırarak enerjini yenile.',
        fullDescription: `
            <p>Kişisel bakım lüks değil, ihtiyaçtır. Cilt bakımı, sıcak bir banyo veya sadece sessizce oturmak bile kendinize verdiğiniz değeri gösterir.</p>
        `,
        category: 'Yaşam',
        image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=2000&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/RPsLpM5h1jE',
        rating: 4.8,
        reviews: []
    },
    {
        id: 'learn-new',
        title: 'Yeni Bir Şey Öğren',
        shortDescription: 'Beynini canlı tutmak için her gün yeni bilgi.',
        fullDescription: `
            <p>Öğrenme süreci beyni genç tutar. Yeni bir hobi, bir tarih bilgisi veya bir yazılım dili... Ne olduğu fark etmez, öğrenmeye devam edin.</p>
        `,
        category: 'Zihinsel',
        image: 'https://images.unsplash.com/photo-1503428593586-e225b476b849?q=80&w=2073&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/472MyoY0rQc',
        rating: 4.6,
        reviews: []
    },
    {
        id: 'plan-ahead',
        title: 'Günü Önceden Planla',
        shortDescription: 'Sabah stresini azaltmak için akşamdan hazırlık.',
        fullDescription: `
            <p>Yatmadan önce ertesi günün planını yapmak, sabah uyandığınızda ne yapacağınızı bilmenin huzurunu verir ve karar yorgunluğunu önler.</p>
        `,
        category: 'Üretkenlik',
        image: 'https://images.unsplash.com/photo-1506784365847-bbad939e9335?q=80&w=2068&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/mNBmG24djoY',
        rating: 4.5,
        reviews: []
    },
    {
        id: 'sleep-hygiene',
        title: 'Uyku Hijyeni',
        shortDescription: 'Kaliteli bir uyku için ortamı düzenle.',
        fullDescription: `
            <p>Karanlık, sessiz ve serin bir oda, kaliteli uykunun anahtarıdır. Düzenli uyku saatleri biyolojik saatinizi onarır.</p>
        `,
        category: 'Sağlık',
        image: 'https://images.unsplash.com/photo-1541781777621-af13943727dd?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/9iMGFqMmUFs',
        rating: 4.9,
        reviews: []
    },
    {
        id: 'feedback',
        title: 'Geri Bildirim İste',
        shortDescription: 'Gelişim için başkalarının görüşlerini al.',
        fullDescription: `
            <p>Kör noktalarımızı görmek zordur. Güvendiğiniz insanlardan dürüst geri bildirimler almak, kişisel gelişiminizde sıçrama yapmanızı sağlar.</p>
        `,
        category: 'Kariyer',
        image: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?q=80&w=2074&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/QJ2Fp6h9c2c',
        rating: 4.3,
        reviews: []
    },
    {
        id: 'active-listening',
        title: 'Aktif Dinleme',
        shortDescription: 'Daha derin ilişkiler için can kulağıyla dinle.',
        fullDescription: `
            <p>Dinlemek, sadece sıranın size gelmesini beklemek değildir. Karşınızdakini anlamak için dinlemek, ilişkilerinizi derinleştirir.</p>
        `,
        category: 'İletişim',
        image: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/QJ2Fp6h9c2c',
        rating: 4.6,
        reviews: []
    },
    {
        id: 'visualization',
        title: 'Görselleştirme',
        shortDescription: 'Hedeflerine ulaşmış gibi hayal et.',
        fullDescription: `
            <p>Zihin, gerçek ile hayali ayırt etmekte zorlanır. Başarınızı detaylıca hayal etmek, beyninizi o başarıya giden yolları bulmaya programlar.</p>
        `,
        category: 'Zihinsel',
        image: 'https://images.unsplash.com/photo-1499209974431-9dddcece7f88?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/inpok4MKVLM',
        rating: 4.7,
        reviews: []
    },
    {
        id: 'affirmations',
        title: 'Olumlamalar',
        shortDescription: 'Pozitif inançlar için kendine tekrar et.',
        fullDescription: `
            <p>"Ben yeterliyim", "Başarabilirim" gibi cümleleri düzenli tekrar etmek, bilinçaltındaki negatif kalıpları kırar.</p>
        `,
        category: 'Ruhsal',
        image: 'https://images.unsplash.com/photo-1493836512294-502baa1986e2?q=80&w=2076&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/U5lZBjWDR_c',
        rating: 4.5,
        reviews: []
    },
    {
        id: 'cold-shower',
        title: 'Soğuk Duş',
        shortDescription: 'Canlılık ve irade için soğuk su terapisi.',
        fullDescription: `
            <p>Sabahları soğuk duş almak, kan dolaşımını hızlandırır, bağışıklığı güçlendirir ve konfor alanından çıkma iradesini geliştirir.</p>
        `,
        category: 'Sağlık',
        image: 'https://images.unsplash.com/photo-1559599238-308793637427?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/9iMGFqMmUFs',
        rating: 4.2,
        reviews: []
    },
    {
        id: 'language',
        title: 'Dil Öğrenme',
        shortDescription: 'Yeni bir kültür ve bakış açısı kazan.',
        fullDescription: `
            <p>Yeni bir dil öğrenmek, beynin gri maddesini artırır ve hafızayı güçlendirir. Günde 15 dakika pratikle başlayın.</p>
        `,
        category: 'Zihinsel',
        image: 'https://images.unsplash.com/photo-1543269865-cbf427effbad?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/472MyoY0rQc',
        rating: 4.8,
        reviews: []
    },
    {
        id: 'cooking',
        title: 'Sağlıklı Yemek Yapma',
        shortDescription: 'Ne yediğini bil, bedenine iyi bak.',
        fullDescription: `
            <p>Kendi yemeğinizi hazırlamak, içerikleri kontrol etmenizi sağlar. Sağlıklı beslenmenin en sürdürülebilir yoludur.</p>
        `,
        category: 'Yaşam',
        image: 'https://images.unsplash.com/photo-1556910103-1c02745a30bf?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/9iMGFqMmUFs',
        rating: 4.7,
        reviews: []
    },
    {
        id: 'volunteering',
        title: 'Gönüllülük',
        shortDescription: 'Başkalarına yardım ederek ruhunu besle.',
        fullDescription: `
            <p>Karşılık beklemeden yardım etmek, toplumsal bağları güçlendirir ve kişisel tatmin duygusunu artırır. Bir amaç uğruna çalışmak hayatı anlamlandırır.</p>
        `,
        category: 'Ruhsal',
        image: 'https://images.unsplash.com/photo-1593113598332-cd288d649433?q=80&w=2070&auto=format&fit=crop',
        videoUrl: 'https://www.youtube.com/embed/U5lZBjWDR_c',
        rating: 4.9,
        reviews: []
    }
];

// Components
function Layout(content) {
    return `
        <nav class="navbar glass">
            <div class="container flex justify-between items-center">
                <a href="#" class="text-gradient" style="font-size: 1.5rem; font-weight: 700; text-decoration: none;">Gelişim</a>
                <div class="flex gap-8">
                    <a href="#" class="nav-link">Ana Sayfa</a>
                    <a href="#dashboard" class="nav-link">Panelim</a>
                </div>
            </div>
        </nav>

        <main style="padding-top: 80px; min-height: calc(100vh - 200px);">
            ${content}
        </main>

        <footer class="glass" style="margin-top: 4rem; padding: 2rem 0; border-top: 1px solid var(--glass-border);">
            <div class="container flex justify-between items-center">
                <p style="color: var(--text-muted);">© 2025 Gelişim App. Tüm hakları saklıdır.</p>
                <div class="flex gap-4">
                    <a href="#" style="color: var(--text-muted);"><i data-lucide="instagram"></i></a>
                    <a href="#" style="color: var(--text-muted);"><i data-lucide="twitter"></i></a>
                </div>
            </div>
        </footer>
    `;
}

function Hero() {
    return `
        <section class="container py-12 flex flex-col items-center justify-center" style="min-height: 60vh; text-align: center;">
            <h1 class="animate-fade-in font-serif" style="font-size: 3.5rem; line-height: 1.2; margin-bottom: 1.5rem;">
                En İyi Versiyonuna<br>
                <span class="text-gradient">Adım At</span>
            </h1>
            <p class="animate-fade-in delay-100" style="font-size: 1.25rem; color: var(--text-muted); max-width: 600px; margin-bottom: 2.5rem;">
                Bilimsel temelli alışkanlıklar, meditasyon pratikleri ve üretkenlik teknikleriyle hayatını dönüştür.
            </p>
            <a href="#catalog" class="btn btn-primary animate-fade-in delay-200">
                Hemen Başla <i data-lucide="arrow-right"></i>
            </a>
        </section>
    `;
}

function BehaviorCard(behavior) {
    return `
        <div class="card glass-panel">
            <img src="${behavior.image}" alt="${behavior.title}" class="card-image">
            <div class="card-content">
                <div class="flex justify-between items-center mb-4">
                    <span style="font-size: 0.875rem; color: var(--accent); font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em;">
                        ${behavior.category}
                    </span>
                    <div class="flex items-center gap-1" style="color: #fbbf24;">
                        <i data-lucide="star" style="width: 16px; height: 16px; fill: currentColor;"></i>
                        <span style="font-weight: 600; font-size: 0.9rem;">${behavior.rating}</span>
                    </div>
                </div>
                <h3 style="font-size: 1.5rem; margin-bottom: 0.5rem;">${behavior.title}</h3>
                <p style="color: var(--text-muted); margin-bottom: 1.5rem; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                    ${behavior.shortDescription}
                </p>
                <a href="#behavior/${behavior.id}" class="btn btn-outline" style="width: 100%; justify-content: center;">
                    İncele
                </a>
            </div>
        </div>
    `;
}

// Pages
function Home() {
    const catalogHtml = behaviors.map(b => BehaviorCard(b)).join('');

    return `
        ${Hero()}
        
        <section id="catalog" class="container py-12">
            <div class="flex justify-between items-end mb-8">
                <div>
                    <h2 class="font-serif" style="font-size: 2.5rem; margin-bottom: 0.5rem;">Keşfet</h2>
                    <p style="color: var(--text-muted);">Senin için seçtiğimiz gelişim araçları</p>
                </div>
            </div>
            
            <div class="grid grid-cols-3">
                ${catalogHtml}
            </div>
        </section>
    `;
}

function BehaviorDetail(id) {
    const behavior = behaviors.find(b => b.id === id);

    if (!behavior) {
        return `<div class="container py-12"><h2>İçerik bulunamadı.</h2></div>`;
    }

    // Check if already in routine
    const myRoutine = JSON.parse(localStorage.getItem('myRoutine')) || [];
    const isAdded = myRoutine.includes(id);

    // Render Reviews
    const reviewsHtml = behavior.reviews.map(r => `
        <div class="glass-panel p-4 mb-4">
            <div class="flex justify-between items-center mb-2">
                <span style="font-weight: 600;">${r.user}</span>
                <div class="flex items-center gap-1" style="color: #fbbf24;">
                    <i data-lucide="star" style="width: 14px;"></i>
                    <span>${r.rating}</span>
                </div>
            </div>
            <p style="color: var(--text-muted);">${r.comment}</p>
        </div>
    `).join('');

    setTimeout(() => {
        // Handle "Add to Routine"
        const btn = document.getElementById('addToRoutineBtn');
        if (btn) {
            btn.addEventListener('click', () => {
                const currentRoutine = JSON.parse(localStorage.getItem('myRoutine')) || [];
                if (!currentRoutine.includes(id)) {
                    currentRoutine.push(id);
                    localStorage.setItem('myRoutine', JSON.stringify(currentRoutine));
                    btn.textContent = 'Listene Eklendi ✓';
                    btn.classList.add('btn-outline');
                    btn.classList.remove('btn-primary');
                    btn.disabled = true;
                }
            });
        }

        // Handle Review Submission (Mock)
        const reviewForm = document.getElementById('reviewForm');
        if (reviewForm) {
            reviewForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const comment = document.getElementById('reviewComment').value;
                const newReviewHtml = `
                    <div class="glass-panel p-4 mb-4 animate-fade-in">
                        <div class="flex justify-between items-center mb-2">
                            <span style="font-weight: 600;">Sen</span>
                            <div class="flex items-center gap-1" style="color: #fbbf24;">
                                <i data-lucide="star" style="width: 14px;"></i>
                                <span>5</span>
                            </div>
                        </div>
                        <p style="color: var(--text-muted);">${comment}</p>
                    </div>
                `;
                document.getElementById('reviewsList').insertAdjacentHTML('afterbegin', newReviewHtml);
                reviewForm.reset();
            });
        }
    }, 0);

    return `
        <div class="container py-12">
            <a href="#" class="btn btn-outline mb-8" style="padding: 0.5rem 1rem; font-size: 0.9rem;">
                <i data-lucide="arrow-left"></i> Geri Dön
            </a>

            <div class="grid grid-cols-3 gap-8">
                <!-- Main Content -->
                <div class="col-span-2" style="grid-column: span 2;">
                    <h1 class="font-serif mb-4" style="font-size: 3rem;">${behavior.title}</h1>
                    <div class="flex items-center gap-4 mb-8">
                        <span class="glass px-3 py-1 rounded-full text-sm">${behavior.category}</span>
                        <div class="flex items-center gap-1" style="color: #fbbf24;">
                            <i data-lucide="star"></i>
                            <span>${behavior.rating}</span>
                        </div>
                    </div>

                    <div class="glass-panel p-8 mb-8">
                        <div style="font-size: 1.1rem; color: var(--text-main);">
                            ${behavior.fullDescription}
                        </div>
                    </div>

                    <h3 class="mb-4 text-2xl">Video Rehber</h3>
                    <div class="glass-panel p-2 mb-8" style="aspect-ratio: 16/9;">
                        <iframe width="100%" height="100%" src="${behavior.videoUrl}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen style="border-radius: 0.5rem;"></iframe>
                    </div>

                    <h3 class="mb-4 text-2xl">Kullanıcı Yorumları</h3>
                    <div class="glass-panel p-8">
                        <form id="reviewForm" class="mb-8">
                            <textarea id="reviewComment" class="glass w-full p-4 rounded-lg mb-4" style="width: 100%; background: rgba(0,0,0,0.2); border: 1px solid var(--glass-border); color: white;" placeholder="Deneyimlerini paylaş..." required></textarea>
                            <button type="submit" class="btn btn-primary">Yorum Yap</button>
                        </form>
                        <div id="reviewsList">
                            ${reviewsHtml}
                        </div>
                    </div>
                </div>

                <!-- Sidebar -->
                <div>
                    <div class="glass-panel p-6 sticky" style="position: sticky; top: 100px;">
                        <img src="${behavior.image}" alt="${behavior.title}" class="rounded-lg mb-6 w-full object-cover" style="height: 200px;">
                        <h3 class="mb-2">Harekete Geç</h3>
                        <p class="text-muted mb-6 text-sm">Bu davranışı günlük rutinine ekleyerek gelişimini takip et.</p>
                        <button id="addToRoutineBtn" class="btn ${isAdded ? 'btn-outline' : 'btn-primary'} w-full justify-center" ${isAdded ? 'disabled' : ''}>
                            ${isAdded ? 'Listene Eklendi ✓' : 'Rutinime Ekle'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function Dashboard() {
    const myRoutineIds = JSON.parse(localStorage.getItem('myRoutine')) || [];
    const myBehaviors = behaviors.filter(b => myRoutineIds.includes(b.id));

    setTimeout(() => {
        // Handle Remove
        document.querySelectorAll('.remove-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.target.dataset.id;
                const currentRoutine = JSON.parse(localStorage.getItem('myRoutine')) || [];
                const newRoutine = currentRoutine.filter(item => item !== id);
                localStorage.setItem('myRoutine', JSON.stringify(newRoutine));

                // Reload dashboard (simple way)
                window.location.reload();
            });
        });
    }, 0);

    if (myBehaviors.length === 0) {
        return `
            <div class="container py-12 text-center">
                <h1 class="font-serif mb-4">Henüz Bir Rutin Oluşturmadın</h1>
                <p class="text-muted mb-8">Gelişim yolculuğuna başlamak için kataloğu incele.</p>
                <a href="#" class="btn btn-primary">Davranışları Keşfet</a>
            </div>
        `;
    }

    return `
        <div class="container py-12">
            <h1 class="font-serif mb-2">Gelişim Panelin</h1>
            <p class="text-muted mb-8">Takip ettiğin ${myBehaviors.length} alışkanlık var.</p>

            <div class="grid grid-cols-3">
                ${myBehaviors.map(b => `
                    <div class="card glass-panel relative">
                        <img src="${b.image}" alt="${b.title}" class="card-image">
                        <div class="card-content">
                            <h3 class="mb-2">${b.title}</h3>
                            <div class="flex justify-between items-center mt-4">
                                <a href="#behavior/${b.id}" class="btn btn-outline btn-sm" style="font-size: 0.8rem; padding: 0.5rem 1rem;">Detay</a>
                                <button class="remove-btn" data-id="${b.id}" style="background: none; border: none; color: #ef4444; cursor: pointer; font-weight: 600;">
                                    Kaldır
                                </button>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

// Router & App
const app = document.getElementById('app');

function router() {
    const hash = window.location.hash || '#';
    let content = '';

    if (hash === '#') {
        content = Home();
    } else if (hash.startsWith('#behavior/')) {
        const id = hash.split('/')[1];
        content = BehaviorDetail(id);
    } else if (hash === '#dashboard') {
        content = Dashboard();
    } else {
        content = Home();
    }

    app.innerHTML = Layout(content);

    // Re-initialize icons
    if (window.lucide) {
        window.lucide.createIcons();
    }

    // Scroll to top
    window.scrollTo(0, 0);
}

window.addEventListener('hashchange', router);
window.addEventListener('load', router);
